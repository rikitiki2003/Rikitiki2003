EL SUAVECITO — iPhone installable web app

WHAT'S INCLUDED
- Existing 19 duty-night earnings preloaded (total $1,475.00)
- Add earnings and subtract expenses
- Automatically calculated balance
- Transaction history and delete
- Export CSV backup
- Offline app shell after first successful load
- Local device storage using browser localStorage

IMPORTANT
This is a Progressive Web App (PWA). To install it on iPhone, it must be hosted on an HTTPS website.
The ZIP itself is the app source; it cannot be installed directly from the ZIP.

PUBLISHING
1. Upload all files in this folder to a static HTTPS host (for example, a GitHub Pages site).
2. Open the published HTTPS address in Safari on your iPhone.
3. Tap Share, then Add to Home Screen.
4. Enable "Open as Web App" if that option appears, then tap Add.

DATA & BACKUPS
Records are stored locally in Safari on that iPhone. They do not automatically sync to another device.
Use Export CSV regularly and keep a backup. Clearing Safari website data may erase the records.
